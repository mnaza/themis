Full cool documentation is available in our [wiki](https://github.com/cossacklabs/themis/wiki).
For offline use you might want to:

```
git clone https://github.com/cossacklabs/themis.wiki.git
```

This folder contains examples and, in nearest future, will contain tutorials/demo apps for all platforms Themis works on.
