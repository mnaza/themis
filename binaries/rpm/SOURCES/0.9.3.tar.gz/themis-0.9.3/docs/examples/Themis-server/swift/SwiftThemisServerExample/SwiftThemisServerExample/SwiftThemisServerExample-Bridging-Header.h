//
//  SwiftThemisServerExample-Bridging-Header.h
//  SwiftThemisServerExample
//
//  Created by Anastasi Voitova on 19.04.16.
//  Copyright © 2016 CossackLabs. All rights reserved.
//

#ifndef SwiftThemisServerExample_Bridging_Header_h
#define SwiftThemisServerExample_Bridging_Header_h

    #import <objcthemis/objcthemis.h>

#endif /* SwiftThemisServerExample_Bridging_Header_h */