//
//  AppDelegate.h
//  WorkingWithThemisServer
//
//  Created by Anastasi Voitova on 24.10.15.
//  Copyright © 2015 Stanfy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

