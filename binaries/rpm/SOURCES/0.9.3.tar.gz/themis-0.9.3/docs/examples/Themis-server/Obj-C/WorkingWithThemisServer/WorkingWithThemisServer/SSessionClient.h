#import <Foundation/Foundation.h>

@interface SSessionClient : NSObject

- (void)runSecureSessionCITest;

@end