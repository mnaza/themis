#import <Foundation/Foundation.h>


@interface SMessageClient : NSObject

- (void)runSecureMessageCITest;

@end
