//
//  ViewController.swift
//  ThemisSwift
//
//  Created by Anastasi Voitova on 17.04.16.
//  Copyright © 2016 CossackLabs. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

// Look inside console, young padavan!

}
