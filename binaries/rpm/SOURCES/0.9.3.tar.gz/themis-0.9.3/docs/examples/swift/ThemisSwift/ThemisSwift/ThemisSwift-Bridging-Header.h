//
//  ThemisSwift-Bridging-Header.h
//  ThemisSwift
//
//  Created by Anastasi Voitova on 18.04.16.
//  Copyright © 2016 CossackLabs. All rights reserved.
//

#ifndef ThemisSwift_Bridging_Header_h
#define ThemisSwift_Bridging_Header_h

    #import <objcthemis/objcthemis.h>

#endif /* ThemisSwift_Bridging_Header_h */
